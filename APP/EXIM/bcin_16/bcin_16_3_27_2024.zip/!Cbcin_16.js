Ext.define("NJC.EXIM.bcin_16.Cbcin_16", {
  extend: "Ext.app.ViewController",
  alias: "controller.Cbcin_16",
  init: function (view) {
    this.control({
      "bcin_16 button[pid=btrefresh]": { click: this.btrefresh_click },
      "bcin_16 combobox[name=CBO_FILTERKEY]": { select: this.btrefresh_click },
      "FRMbcin_16 button[pid=bttambah_dokumen]": { click: this.bttambah_dokumen_click },
      "FRMbcin_16 button[pid=btsearch]": { click: this.btsearch_click },
    });
    this.listen({
      store: {},
    });
    this.var_global = {
      jwt: localStorage.getItem("ST_NJC_JWT"),
    };
    this.var_definition = {};
    this.renderpage();
  },
  formatqty: function (value) {
    var text = Ext.util.Format.number(value, "0,000.00/i");
    return text;
  },
  formatAmount: function (value) {
    var text = Ext.util.Format.number(value, "0,000.00/i");
    return text;
  },
  renderpage: function () {
    try {
      console.log("load Controller Cbcin_16");
    } catch (ex) {
      COMP.TipToast.toast("Error", ex.message, { cls: "danger", delay: 2000 });
    }
  },
  btrefresh_click: function () {
    try {
      var GRID = Ext.ComponentQuery.query("bcin_23 GRIDbcin_23 grid[pid=GRIDbcin_23]")[0];
      GRID.getStore().load();
    } catch (ex) {
      COMP.TipToast.toast("Error", ex.message, { cls: "danger", delay: 2000 });
    }
  },
  btdetail_rows_click: function (xgrid, rowIndex) {
    try {
      xgrid.getSelectionModel().select(rowIndex);
      var me = this;
      var mainpanel = Ext.ComponentQuery.query("mainpage")[0];
      COMP.run.getmodulepopup("FRMbcin_23", "NJC.EXIM.bcin_23.FRMbcin_23", mainpanel);
    } catch (ex) {
      COMP.TipToast.toast("Error", ex.message, { cls: "danger", delay: 2000 });
    }
  },
  FRMbcin_23_load: function (cmp) {
    try {
      var me = this;
      var mainpanel = Ext.ComponentQuery.query("mainpage")[0];
      var FRM = cmp.query("form")[0];
      var GRIDkontainer = cmp.query("form grid[pid=GRIDbcin_23_kontainer]")[0];
      var GRIDkemasan = cmp.query("form grid[pid=GRIDbcin_23_kemasan]")[0];
      var GRIDdokumen = cmp.query("form grid[pid=GRIDbcin_23_input_dokumen]")[0];
      var GRIDbarang = cmp.query("form grid[pid=GRIDbcin_23_input_item]")[0];
      GRIDkontainer.getStore().removeAll();
      GRIDkemasan.getStore().removeAll();
      GRIDdokumen.getStore().removeAll();
      GRIDbarang.getStore().removeAll();

      var GRID = Ext.ComponentQuery.query("bcin_23 GRIDbcin_23 grid[pid=GRIDbcin_23]")[0];
      var vdt = GRID.getSelectionModel().getSelection()[0].data;
      cmp.setTitle("Edit Dokumen No AJU: " + vdt.NOMOR_AJU);

      var params = Ext.encode({
        method: "proses_edit_dokumen",
        NOMOR_AJU: vdt.NOMOR_AJU,
      });
      var hasil = COMP.run.getservice(vconfig.service_api + "bcin_23/bcin_23", params, "POST", me.var_global.jwt);
      hasil.then(function (content) {
        var val = Ext.decode(content, true);
        if (val.success === "true") {
          if (val.vheader !== null) {
            var dtheader = Ext.decode(val.vheader, true);
            FRM.getForm().setValues(dtheader);
            FRM.getForm().setValues({
              COMBO_CARA_ANGKUT: dtheader.KODE_CARA_ANGKUT,
            });
          }
          if (val.vkontainer !== null) {
            var dtkontainer = Ext.decode(val.vkontainer, true);
            GRIDkontainer.getStore().add(dtkontainer);
          }
          if (val.vkemasan !== null) {
            var dtkemasan = Ext.decode(val.vkemasan, true);
            GRIDkemasan.getStore().add(dtkemasan);
          }
          if (val.vdokumen !== null) {
            var dtdokumen = Ext.decode(val.vdokumen, true);
            GRIDdokumen.getStore().add(dtdokumen);
          }
          if (val.vbarang !== null) {
            var dtbarang = Ext.decode(val.vbarang, true);
            GRIDbarang.getStore().add(dtbarang);
          }
          if (val.vinvoice !== null) {
            var dtinvoice = Ext.decode(val.vinvoice, true);
            FRM.getForm().setValues({
              INVOICE_NOMOR_DOKUMEN: dtinvoice.NOMOR_DOKUMEN,
              INVOICE_TANGGAL_DOKUMEN: moment(dtinvoice.TANGGAL_DOKUMEN).format("YYYY-MM-DD"),
            });
          }
          if (val.vimpor !== null) {
            var dtimpor = Ext.decode(val.vimpor, true);
            FRM.getForm().setValues({
              IMPOR_NOMOR_DOKUMEN: dtimpor.NOMOR_DOKUMEN,
              IMPOR_TANGGAL_DOKUMEN: moment(dtimpor.TANGGAL_DOKUMEN).format("YYYY-MM-DD"),
            });
          }
          if (val.vlc !== null) {
            var dtlc = Ext.decode(val.vlc, true);
            FRM.getForm().setValues({
              LC_NOMOR_DOKUMEN: dtlc.NOMOR_DOKUMEN,
              LC_TANGGAL_DOKUMEN: moment(dtlc.TANGGAL_DOKUMEN).format("YYYY-MM-DD"),
            });
          }
          if (val.vawb !== null) {
            var dtawb = Ext.decode(val.vawb, true);
            FRM.getForm().setValues({
              AWB_NOMOR_DOKUMEN: dtawb.NOMOR_DOKUMEN,
              AWB_TANGGAL_DOKUMEN: moment(dtawb.TANGGAL_DOKUMEN).format("YYYY-MM-DD"),
            });
          }
          COMP.TipToast.toast("Success", val.message, { cls: "success", delay: 3000 });
        } else {
          COMP.TipToast.toast("Error", val.message, { cls: "danger", delay: 3000 });
        }
      }, this);
    } catch (ex) {
      COMP.TipToast.toast("Error", ex.message, { cls: "danger", delay: 2000 });
    }
  },
  FRMbcin_23_btcancel_click: function () {
    try {
      var popup = Ext.ComponentQuery.query("FRMbcin_23")[0];
      var GRID = Ext.ComponentQuery.query("bcin_23 GRIDbcin_23 grid[pid=GRIDbcin_23]")[0];
      var FRM_MAIN = Ext.ComponentQuery.query("FRMbcin_23 form")[0];
      var MAIN_dtval = FRM_MAIN.getValues(false, false, false, true);
      var me = this;
      Ext.MessageBox.confirm(
        "Konfirmasi hapus dokumen",
        //
        "<b>Syarat untuk Proses Hapus Dokumen BC: </b>" +
          //
          "<ol>" +
          "<li>Dokumen belum terkirim ke Aplikasi CEISA</li>" +
          "<li>Dokumen belum proses Receiving (penerimaan Item/Part)</li>" +
          "</ol>" +
          "<i>" +
          "Pastikan Data Invoice diperiksa kembali di menu Sumber Data" +
          "</i>",

        function (button) {
          if (button === "yes") {
            var params = Ext.encode({
              method: "proses_cancel_dokumen",
              NOMOR_AJU: MAIN_dtval.NOMOR_AJU,
            });
            var hasil = COMP.run.getservice(vconfig.service_api + "bcin_23/bcin_23", params, "POST", me.var_global.jwt);
            hasil.then(function (content) {
              var val = Ext.decode(content, true);
              if (val.success === "true") {
                GRID.getStore().load();
                popup.close();
                COMP.TipToast.toast("Success", val.message, { cls: "success", delay: 3000 });
              } else {
                popup.close();
                COMP.TipToast.toast("Error", val.message, { cls: "danger", delay: 3000 });
              }
            }, this);
          }
        },
        this
      );
    } catch (ex) {
      COMP.TipToast.toast("Error", ex.message, { cls: "danger", delay: 2000 });
    }
  },
  FRMbcin_23_btsendtoceisa_click: function () {
    try {
      console.log("send to ceisa");
    } catch (ex) {
      COMP.TipToast.toast("Error", ex.message, { cls: "danger", delay: 2000 });
    }
  },
  edit_detailbarang_click: function (xgrid, rowIndex) {
    try {
      xgrid.getSelectionModel().select(rowIndex);
      var me = this;
      var mainpanel = Ext.ComponentQuery.query("mainpage")[0];
      COMP.run.getmodulepopup("FRMbcin_23_item", "NJC.EXIM.bcin_23.FRMbcin_23_item", mainpanel);
    } catch (ex) {
      COMP.TipToast.toast("Error", ex.message, { cls: "danger", delay: 2000 });
    }
  },
  FRMbcin_23_item_load: function (cmp) {
    try {
      var me = this;
      var mainpanel = Ext.ComponentQuery.query("mainpage")[0];
      var FRM = cmp.query("form")[0];

      var GRID = Ext.ComponentQuery.query("bcin_23 GRIDbcin_23 grid[pid=GRIDbcin_23]")[0];
      var vdt = GRID.getSelectionModel().getSelection()[0].data;

      var GRIDitem = Ext.ComponentQuery.query("FRMbcin_23 form grid[pid=GRIDbcin_23_input_item]")[0];
      var vitem = GRIDitem.getSelectionModel().getSelection()[0].data;

      cmp.setTitle("Edit Item Seri Barang: " + vitem.SERI_BARANG + " No AJU: " + vdt.NOMOR_AJU);

      var params = Ext.encode({
        method: "proses_edit_item_dokumen",
        NOMOR_AJU: vdt.NOMOR_AJU,
        SERI_BARANG: vitem.SERI_BARANG,
      });

      var hasil = COMP.run.getservice(vconfig.service_api + "bcin_23/bcin_23", params, "POST", me.var_global.jwt);
      hasil.then(function (content) {
        var val = Ext.decode(content, true);
        if (val.success === "true") {
          FRM.getForm().setValues(val.data);
        } else {
          COMP.TipToast.toast("Error", val.message, { cls: "danger", delay: 3000 });
        }
      }, this);
    } catch (ex) {
      COMP.TipToast.toast("Error", ex.message, { cls: "danger", delay: 2000 });
    }
  },
  btsearch_click: function (btn) {
    try {
      var me = this;
      var mainpanel = Ext.ComponentQuery.query("mainpage")[0];
      var popup = Ext.define("NJC.EXIM.bcin_23.popup_btsearch", {
        extend: "Ext.window.Window",
        alias: "widget.popup_btsearch",
        reference: "popup_btsearch",
        title: btn.vdata.title,
        modal: true,
        closeAction: "destroy",
        centered: true,
        autoScroll: true,
        width: mainpanel.getWidth() * btn.vdata.popupwidth,
        height: mainpanel.getHeight() * btn.vdata.popupheight,
        layout: { type: "vbox", pack: "start", align: "stretch" },
        bodyStyle: "background:#FFFFFF;background-color:#FFFFFF",
        items: [
          {
            xtype: "grid",
            pid: "GRIDpopup_selectsupplier",
            emptyText: "No Matching Records",
            autoScroll: true,
            flex: 1,
            plugins: ["filterfield"],
            viewConfig: {
              enableTextSelection: true,
            },
            store: me.btsearch_store(btn.vdata.modulename),
            columns: me.btsearch_column(btn.vdata.modulename),
            bbar: {
              xtype: "pagingtoolbar",
              displayInfo: true,
              displayMsg: "Total Data {2}",
              emptyMsg: "No topics to display",
            },
            listeners: {
              itemdblclick: function (grid, rec) {
                switch (btn.vdata.modulename) {
                  case "negara":
                    var FRM = Ext.ComponentQuery.query("FRMbcin_23 form")[0];
                    var popup = Ext.ComponentQuery.query("popup_btsearch")[0];
                    FRM.getForm().setValues({
                      KODE_BENDERA_NAME: rec.data.URAIAN_NEGARA,
                      KODE_BENDERA: rec.data.KODE_NEGARA,
                    });
                    popup.close();
                    return;
                  case "pelabuhanmuat":
                    var FRM = Ext.ComponentQuery.query("FRMbcin_23 form")[0];
                    var popup = Ext.ComponentQuery.query("popup_btsearch")[0];
                    FRM.getForm().setValues({
                      KODE_PEL_MUATNAME: rec.data.URAIAN_PELABUHAN,
                      KODE_PEL_MUAT: rec.data.KODE_PELABUHAN,
                    });
                    popup.close();
                    return;
                  case "pelabuhantransit":
                    var FRM = Ext.ComponentQuery.query("FRMbcin_23 form")[0];
                    var popup = Ext.ComponentQuery.query("popup_btsearch")[0];
                    FRM.getForm().setValues({
                      KODE_PEL_TRANSITNAME: rec.data.URAIAN_PELABUHAN,
                      KODE_PEL_TRANSIT: rec.data.KODE_PELABUHAN,
                    });
                    popup.close();
                    return;
                  case "pelabuhanbongkar":
                    var FRM = Ext.ComponentQuery.query("FRMbcin_23 form")[0];
                    var popup = Ext.ComponentQuery.query("popup_btsearch")[0];
                    FRM.getForm().setValues({
                      KODE_PEL_BONGKARNAME: rec.data.URAIAN_PELABUHAN,
                      KODE_PEL_BONGKAR: rec.data.KODE_PELABUHAN,
                    });
                    popup.close();
                    return;
                  case "kppbcbongkar":
                    var FRM = Ext.ComponentQuery.query("FRMbcin_23 form")[0];
                    var popup = Ext.ComponentQuery.query("popup_btsearch")[0];
                    FRM.getForm().setValues({
                      KODE_KANTOR_BONGKARNAME: rec.data.URAIAN_KANTOR,
                      KODE_KANTOR_BONGKAR: rec.data.KODE_KANTOR,
                    });
                    popup.close();
                    return;
                  case "kppbcpengawas":
                    var FRM = Ext.ComponentQuery.query("FRMbcin_23 form")[0];
                    var popup = Ext.ComponentQuery.query("popup_btsearch")[0];
                    FRM.getForm().setValues({
                      KODE_KANTORNAME: rec.data.URAIAN_KANTOR,
                      KODE_KANTOR: rec.data.KODE_KANTOR,
                    });
                    popup.close();
                    return;
                  case "tujuantpb":
                    var FRM = Ext.ComponentQuery.query("FRMbcin_23 form")[0];
                    var popup = Ext.ComponentQuery.query("popup_btsearch")[0];
                    FRM.getForm().setValues({
                      KODE_TUJUAN_TPBNAME: rec.data.URAIAN_TUJUAN_TPB,
                      KODE_TUJUAN_TPB: rec.data.KODE_TUJUAN_TPB,
                    });
                    popup.close();
                    return;
                  case "tps":
                    var FRM = Ext.ComponentQuery.query("FRMbcin_23 form")[0];
                    var popup = Ext.ComponentQuery.query("popup_btsearch")[0];
                    FRM.getForm().setValues({
                      KODE_TPS_NAME: rec.data.URAIAN_TPS,
                      KODE_TPS: rec.data.KODE_TPS,
                    });
                    popup.close();
                    return;
                  case "valuta":
                    var FRM = Ext.ComponentQuery.query("FRMbcin_23 form")[0];
                    var popup = Ext.ComponentQuery.query("popup_btsearch")[0];
                    FRM.getForm().setValues({
                      KODE_VALUTA_NAME: rec.data.URAIAN_VALUTA,
                      KODE_VALUTA: rec.data.KODE_VALUTA,
                    });
                    popup.close();
                    return;
                  case "harga":
                    var FRM = Ext.ComponentQuery.query("FRMbcin_23 form")[0];
                    var popup = Ext.ComponentQuery.query("popup_btsearch")[0];
                    FRM.getForm().setValues({
                      KODE_CARA_BAYARNAME: rec.data.URAIAN_HARGA,
                      KODE_CARA_BAYAR: rec.data.KODE_HARGA,
                    });
                    popup.close();
                    return;
                }
              },
            },
          },
        ],
      });
      COMP.run.getmodulepopup("popup_btsearch", popup, this.getView());
    } catch (ex) {
      COMP.TipToast.toast("Error", ex.message, { cls: "danger", delay: 2000 });
    }
  },
  btsearch_column: function (modulename) {
    try {
      switch (modulename) {
        case "negara":
          return [
            { xtype: "rownumberer", width: 40 },
            { header: "KODE NEGARA", dataIndex: "KODE_NEGARA", sortable: true, width: 100, filter: { xtype: "textfield" } },
            { header: "NAMA NEGARA", dataIndex: "URAIAN_NEGARA", sortable: true, width: 200, filter: { xtype: "textfield" } },
          ];
        case "pelabuhanmuat":
          return [
            { xtype: "rownumberer", width: 40 },
            { header: "KODE PELABUHAN", dataIndex: "KODE_PELABUHAN", sortable: true, width: 100, filter: { xtype: "textfield" } },
            { header: "NAMA PELABUHAN", dataIndex: "URAIAN_PELABUHAN", sortable: true, width: 200, filter: { xtype: "textfield" } },
          ];
        case "pelabuhantransit":
          return [
            { xtype: "rownumberer", width: 40 },
            { header: "KODE PELABUHAN", dataIndex: "KODE_PELABUHAN", sortable: true, width: 100, filter: { xtype: "textfield" } },
            { header: "NAMA PELABUHAN", dataIndex: "URAIAN_PELABUHAN", sortable: true, width: 200, filter: { xtype: "textfield" } },
          ];
        case "pelabuhanbongkar":
          return [
            { xtype: "rownumberer", width: 40 },
            { header: "KODE PELABUHAN", dataIndex: "KODE_PELABUHAN", sortable: true, width: 100, filter: { xtype: "textfield" } },
            { header: "NAMA PELABUHAN", dataIndex: "URAIAN_PELABUHAN", sortable: true, width: 200, filter: { xtype: "textfield" } },
          ];
        case "kppbcbongkar":
          return [
            { xtype: "rownumberer", width: 40 },
            { header: "KODE KANTOR", dataIndex: "KODE_KANTOR", sortable: true, width: 100, filter: { xtype: "textfield" } },
            { header: "NAMA KANTOR", dataIndex: "URAIAN_KANTOR", sortable: true, width: 200, filter: { xtype: "textfield" } },
          ];
        case "kppbcpengawas":
          return [
            { xtype: "rownumberer", width: 40 },
            { header: "KODE KANTOR", dataIndex: "KODE_KANTOR", sortable: true, width: 100, filter: { xtype: "textfield" } },
            { header: "NAMA KANTOR", dataIndex: "URAIAN_KANTOR", sortable: true, width: 200, filter: { xtype: "textfield" } },
          ];
        case "tujuantpb":
          return [
            { xtype: "rownumberer", width: 40 },
            { header: "KODE TUJUAN TPB", dataIndex: "KODE_TUJUAN_TPB", sortable: true, width: 100, filter: { xtype: "textfield" } },
            { header: "NAMA TUJUAN TPB", dataIndex: "URAIAN_TUJUAN_TPB", sortable: true, width: 350, filter: { xtype: "textfield" } },
          ];
        case "tps":
          return [
            { xtype: "rownumberer", width: 40 },
            { header: "KODE TPS", dataIndex: "KODE_TPS", sortable: true, width: 100, filter: { xtype: "textfield" } },
            { header: "NAMA TPS", dataIndex: "URAIAN_TPS", sortable: true, width: 200, filter: { xtype: "textfield" } },
          ];
        case "valuta":
          return [
            { xtype: "rownumberer", width: 40 },
            { header: "KODE VALUTA", dataIndex: "KODE_VALUTA", sortable: true, width: 100, filter: { xtype: "textfield" } },
            { header: "NAMA VALUTA", dataIndex: "URAIAN_VALUTA", sortable: true, width: 200, filter: { xtype: "textfield" } },
          ];
        case "harga":
          return [
            { xtype: "rownumberer", width: 40 },
            { header: "KODE HARGA", dataIndex: "KODE_HARGA", sortable: true, width: 100, filter: { xtype: "textfield" } },
            { header: "NAMA HARGA", dataIndex: "URAIAN_HARGA", sortable: true, width: 350, filter: { xtype: "textfield" } },
          ];
        default:
          return false;
      }
    } catch (ex) {
      COMP.TipToast.toast("Error", ex.message, { cls: "danger", delay: 2000 });
    }
  },
  btsearch_store: function (modulename) {
    try {
      switch (modulename) {
        case "negara":
          return {
            autoLoad: true,
            remoteSort: true,
            remoteFilter: true,
            pageSize: 20,
            proxy: {
              type: "ajax",
              disableCaching: false,
              noCache: false,
              headers: { Authorization: "Bearer " + localStorage.getItem("ST_NJC_JWT") },
              actionMethods: { read: "POST" },
              url: vconfig.service_api + "negara/negaras",
              extraParams: {
                method: "read",
                module: "bcin23",
              },
              reader: {
                type: "json",
                rootProperty: "Rows",
                totalProperty: "TotalRows",
                successProperty: "success",
              },
            },
          };
        case "pelabuhanmuat":
          return {
            autoLoad: true,
            remoteSort: true,
            remoteFilter: true,
            pageSize: 20,
            proxy: {
              type: "ajax",
              disableCaching: false,
              noCache: false,
              headers: { Authorization: "Bearer " + localStorage.getItem("ST_NJC_JWT") },
              actionMethods: { read: "POST" },
              url: vconfig.service_api + "pelabuhan/pelabuhans",
              extraParams: {
                method: "read",
                module: "bcin23",
              },
              reader: {
                type: "json",
                rootProperty: "Rows",
                totalProperty: "TotalRows",
                successProperty: "success",
              },
            },
          };
        case "pelabuhantransit":
          return {
            autoLoad: true,
            remoteSort: true,
            remoteFilter: true,
            pageSize: 20,
            proxy: {
              type: "ajax",
              disableCaching: false,
              noCache: false,
              headers: { Authorization: "Bearer " + localStorage.getItem("ST_NJC_JWT") },
              actionMethods: { read: "POST" },
              url: vconfig.service_api + "pelabuhan/pelabuhans",
              extraParams: {
                method: "read",
                module: "bcin23",
              },
              reader: {
                type: "json",
                rootProperty: "Rows",
                totalProperty: "TotalRows",
                successProperty: "success",
              },
            },
          };
        case "pelabuhanbongkar":
          return {
            autoLoad: true,
            remoteSort: true,
            remoteFilter: true,
            pageSize: 20,
            proxy: {
              type: "ajax",
              disableCaching: false,
              noCache: false,
              headers: { Authorization: "Bearer " + localStorage.getItem("ST_NJC_JWT") },
              actionMethods: { read: "POST" },
              url: vconfig.service_api + "pelabuhan/pelabuhans",
              extraParams: {
                method: "read",
                module: "bcin23",
              },
              reader: {
                type: "json",
                rootProperty: "Rows",
                totalProperty: "TotalRows",
                successProperty: "success",
              },
            },
          };
        case "kppbcbongkar":
          return {
            autoLoad: true,
            remoteSort: true,
            remoteFilter: true,
            pageSize: 20,
            proxy: {
              type: "ajax",
              disableCaching: false,
              noCache: false,
              headers: { Authorization: "Bearer " + localStorage.getItem("ST_NJC_JWT") },
              actionMethods: { read: "POST" },
              url: vconfig.service_api + "referensi_kantor_pabean/referensi_kantor_pabeans",
              extraParams: {
                method: "read",
                module: "bcin23",
              },
              reader: {
                type: "json",
                rootProperty: "Rows",
                totalProperty: "TotalRows",
                successProperty: "success",
              },
            },
          };
        case "kppbcpengawas":
          return {
            autoLoad: true,
            remoteSort: true,
            remoteFilter: true,
            pageSize: 20,
            proxy: {
              type: "ajax",
              disableCaching: false,
              noCache: false,
              headers: { Authorization: "Bearer " + localStorage.getItem("ST_NJC_JWT") },
              actionMethods: { read: "POST" },
              url: vconfig.service_api + "referensi_kantor_pabean/referensi_kantor_pabeans",
              extraParams: {
                method: "read",
                module: "bcin23",
              },
              reader: {
                type: "json",
                rootProperty: "Rows",
                totalProperty: "TotalRows",
                successProperty: "success",
              },
            },
          };
        case "tujuantpb":
          return {
            autoLoad: true,
            remoteSort: true,
            remoteFilter: true,
            pageSize: 20,
            proxy: {
              type: "ajax",
              disableCaching: false,
              noCache: false,
              headers: { Authorization: "Bearer " + localStorage.getItem("ST_NJC_JWT") },
              actionMethods: { read: "POST" },
              url: vconfig.service_api + "tujuantpb/tujuantpbs",
              extraParams: {
                method: "read",
                module: "bcin23",
              },
              reader: {
                type: "json",
                rootProperty: "Rows",
                totalProperty: "TotalRows",
                successProperty: "success",
              },
            },
          };
        case "tps":
          return {
            autoLoad: true,
            remoteSort: true,
            remoteFilter: true,
            pageSize: 20,
            proxy: {
              type: "ajax",
              disableCaching: false,
              noCache: false,
              headers: { Authorization: "Bearer " + localStorage.getItem("ST_NJC_JWT") },
              actionMethods: { read: "POST" },
              url: vconfig.service_api + "master_tps/master_tpss",
              extraParams: {
                method: "read",
                module: "bcin23",
              },
              reader: {
                type: "json",
                rootProperty: "Rows",
                totalProperty: "TotalRows",
                successProperty: "success",
              },
            },
          };
        case "valuta":
          return {
            autoLoad: true,
            remoteSort: true,
            remoteFilter: true,
            pageSize: 20,
            proxy: {
              type: "ajax",
              disableCaching: false,
              noCache: false,
              headers: { Authorization: "Bearer " + localStorage.getItem("ST_NJC_JWT") },
              actionMethods: { read: "POST" },
              url: vconfig.service_api + "valuta/valutas",
              extraParams: {
                method: "read",
                module: "bcin23",
              },
              reader: {
                type: "json",
                rootProperty: "Rows",
                totalProperty: "TotalRows",
                successProperty: "success",
              },
            },
          };
        case "harga":
          return {
            autoLoad: true,
            remoteSort: true,
            remoteFilter: true,
            pageSize: 20,
            proxy: {
              type: "ajax",
              disableCaching: false,
              noCache: false,
              headers: { Authorization: "Bearer " + localStorage.getItem("ST_NJC_JWT") },
              actionMethods: { read: "POST" },
              url: vconfig.service_api + "harga/hargas",
              extraParams: {
                method: "read",
                module: "bcin23",
              },
              reader: {
                type: "json",
                rootProperty: "Rows",
                totalProperty: "TotalRows",
                successProperty: "success",
              },
            },
          };
        default:
          return false;
      }
    } catch (ex) {
      COMP.TipToast.toast("Error", ex.message, { cls: "danger", delay: 2000 });
    }
  },
  bttambah_dokumen_click: function () {
    try {
      var me = this;

      var griddokumen = Ext.ComponentQuery.query("FRMbcin_23 grid[pid=GRIDbcin_23_input_dokumen]")[0];

      var mainpanel = Ext.ComponentQuery.query("mainpage")[0];
      var popup = Ext.define("NJC.EXIM.bcin_23.popup_btadddokumen", {
        extend: "Ext.window.Window",
        alias: "widget.popup_btadddokumen",
        reference: "popup_btadddokumen",
        title: "Tambah Dokumen",
        modal: true,
        closeAction: "destroy",
        centered: true,
        autoScroll: true,
        width: mainpanel.getWidth() * 0.5,
        height: mainpanel.getHeight() * 0.6,
        layout: { type: "vbox", pack: "start", align: "stretch" },
        bodyStyle: "background:#FFFFFF;background-color:#FFFFFF",
        items: [
          {
            xtype: "grid",
            pid: "GRIDpopup_btadddokumen",
            emptyText: "No Matching Records",
            autoScroll: true,
            flex: 1,
            plugins: ["filterfield"],
            viewConfig: {
              enableTextSelection: true,
            },
            store: {
              autoLoad: true,
              remoteSort: false,
              remoteFilter: false,
              pageSize: 0,
              proxy: {
                type: "ajax",
                disableCaching: false,
                noCache: false,
                headers: { Authorization: "Bearer " + localStorage.getItem("ST_NJC_JWT") },
                actionMethods: { read: "POST" },
                url: vconfig.service_api + "referensi_dokumen/referensi_dokumens",
                reader: {
                  type: "json",
                  rootProperty: "Rows",
                  totalProperty: "TotalRows",
                  successProperty: "success",
                },
              },
              listeners: {
                beforeload: function (store, operation, eOpts) {
                  var params = [{ property: "KODE_DOKUMEN!=", value: "380" }];
                  operation.setParams({
                    keywhere: Ext.encode(params),
                  });
                },
              },
            },
            columns: [
              { header: "KODE", dataIndex: "KODE_DOKUMEN", sortable: true, width: 65, filter: { xtype: "textfield" } },
              { header: "TIPE", dataIndex: "TIPE_DOKUMEN", sortable: true, width: 65, filter: { xtype: "textfield" } },
              { header: "URAIAN", dataIndex: "URAIAN_DOKUMEN", sortable: true, flex: 1, filter: { xtype: "textfield" } },
            ],
            bbar: {
              xtype: "pagingtoolbar",
              displayInfo: true,
              displayMsg: "Total Data {2}",
              emptyMsg: "No topics to display",
            },
            listeners: {
              itemdblclick: function (grid, rec) {
                try {
                  var griddokumen = Ext.ComponentQuery.query("FRMbcin_23 grid[pid=GRIDbcin_23_input_dokumen]")[0];

                  var rec = {
                    KODE_JENIS_DOKUMEN: rec.data.KODE_DOKUMEN,
                    NOMOR_DOKUMEN: "XXXXX",
                    TANGGAL_DOKUMEN: moment(new Date()).format("YYYY-MM-DD"),
                    URAIAN_DOKUMEN: rec.data.URAIAN_DOKUMEN,
                  };
                  griddokumen.getStore().add(rec);
                  var popup = Ext.ComponentQuery.query("popup_btadddokumen")[0];
                  popup.close();
                } catch (ex) {
                  COMP.TipToast.toast("Error", ex.message, { cls: "danger", delay: 2000 });
                }
              },
            },
          },
        ],
      });
      COMP.run.getmodulepopup("popup_btadddokumen", popup, this.getView());
    } catch (ex) {
      COMP.TipToast.toast("Error", ex.message, { cls: "danger", delay: 2000 });
    }
  },
});
